import React, { useState } from 'react';
import './styles/nasaData.css';
import {
  Globe,
  Radio,
  Flame,
  Layers,
  Mountain,
  Wind,
  Camera,
  LineChart,
  Database,
  ShieldCheck,
  Thermometer,
  Clock,
  Compass
} from 'lucide-react';

import DataOverview from './components/DataOverview.jsx';
import ThermalViewer from './components/ThermalViewer.jsx';
import GeologyMinerals from './components/GeologyMinerals.jsx';
import TopographyElevation from './components/TopographyElevation.jsx';
import AtmosphereObservations from './components/AtmosphereObservations.jsx';
import RoverImagery from './components/RoverImagery.jsx';
import DataVisualizer from './components/DataVisualizer.jsx';
import DatasetSourcesModal from './components/DatasetSourcesModal.jsx';

/**
 * Member 2 - NASA Scientific Data Integration Module
 * 
 * Interplanetary Survival Guide: Martian Map
 * 
 * Provides authentic NASA mission datasets, physical parameters, thermal regimes,
 * mineralogical compositions, topographic laser altimetry, atmospheric weather,
 * rover observations, and interactive data visualization.
 */
export default function NasaScientificDataModule({
  initialTab = 'overview',
  defaultUnit = 'C',
  showSharedHeader = true
}) {
  const [activeTab, setActiveTab] = useState(initialTab);
  const [unit, setUnit] = useState(defaultUnit); // 'C', 'K', 'F'
  const [isSourcesModalOpen, setIsSourcesModalOpen] = useState(false);

  // Helper temperature converter
  const tempConvert = (celsiusVal) => {
    if (typeof celsiusVal !== 'number') return `${celsiusVal}`;
    if (unit === 'K') {
      return `${(celsiusVal + 273.15).toFixed(1)} K`;
    }
    if (unit === 'F') {
      return `${((celsiusVal * 9) / 5 + 32).toFixed(1)}°F`;
    }
    return `${celsiusVal > 0 ? `+${celsiusVal.toFixed(1)}` : celsiusVal.toFixed(1)}°C`;
  };

  return (
    <div className="nasa-module-root">
      {/* Top Telemetry & Mission Control HUD */}
      {showSharedHeader && (
        <header className="nasa-top-hud">
          <div className="nasa-brand">
            <div className="nasa-logo-badge">
              <Globe size={26} />
            </div>
            <div className="nasa-title-group">
              <h1>
                NASA SCIENTIFIC DATA INTEGRATION
                <span className="data-provenance-tag verified" style={{ fontSize: '0.65rem' }}>
                  MODULE 2
                </span>
              </h1>
              <div className="sub">
                Interplanetary Survival Guide: Martian Map • JPL & PDS Science Archive
              </div>
            </div>
          </div>

          <div className="nasa-telemetry-strip">
            <div className="telemetry-item">
              <span className="label">Mars Epoch</span>
              <span className="value">MY 37 • L_s 145.8°</span>
            </div>
            <div className="telemetry-item">
              <span className="label">Jezero Sol</span>
              <span className="value">Sol 921 (Active)</span>
            </div>
            <div className="telemetry-item">
              <span className="label">Atm. Pressure</span>
              <span className="value">768.5 Pa</span>
            </div>
            <div className="telemetry-item">
              <span className="label">Dust Opacity</span>
              <span className="value">τ = 0.37</span>
            </div>

            {/* Unit Switcher */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '3px' }}>
              <span style={{ fontSize: '0.65rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', textTransform: 'uppercase' }}>
                Temp Unit
              </span>
              <div className="unit-toggle-group">
                <button
                  className={`unit-toggle-btn ${unit === 'C' ? 'active' : ''}`}
                  onClick={() => setUnit('C')}
                >
                  °C
                </button>
                <button
                  className={`unit-toggle-btn ${unit === 'K' ? 'active' : ''}`}
                  onClick={() => setUnit('K')}
                >
                  K
                </button>
                <button
                  className={`unit-toggle-btn ${unit === 'F' ? 'active' : ''}`}
                  onClick={() => setUnit('F')}
                >
                  °F
                </button>
              </div>
            </div>

            <button
              onClick={() => setIsSourcesModalOpen(true)}
              className="nasa-btn nasa-btn-outline"
              style={{ fontSize: '0.74rem', padding: '0.45rem 0.85rem' }}
            >
              <Database size={13} color="var(--mars-cyan)" />
              Dataset Provenance
            </button>
          </div>
        </header>
      )}

      {/* Module Domain Navigation Tabs */}
      <nav className="nasa-nav-tabs">
        <button
          className={`nasa-tab-btn ${activeTab === 'overview' ? 'active' : ''}`}
          onClick={() => setActiveTab('overview')}
        >
          <Radio size={15} /> Overview & Telemetry
        </button>
        <button
          className={`nasa-tab-btn ${activeTab === 'atmosphere' ? 'active' : ''}`}
          onClick={() => setActiveTab('atmosphere')}
        >
          <Wind size={15} /> Atmospheric Observations
        </button>
        <button
          className={`nasa-tab-btn ${activeTab === 'thermal' ? 'active' : ''}`}
          onClick={() => setActiveTab('thermal')}
        >
          <Flame size={15} /> Thermal & Surface Energy
        </button>
        <button
          className={`nasa-tab-btn ${activeTab === 'geology' ? 'active' : ''}`}
          onClick={() => setActiveTab('geology')}
        >
          <Layers size={15} /> Geology & Minerals
        </button>
        <button
          className={`nasa-tab-btn ${activeTab === 'topography' ? 'active' : ''}`}
          onClick={() => setActiveTab('topography')}
        >
          <Mountain size={15} /> Topography & Elevation
        </button>
        <button
          className={`nasa-tab-btn ${activeTab === 'rover-imagery' ? 'active' : ''}`}
          onClick={() => setActiveTab('rover-imagery')}
        >
          <Camera size={15} /> Mars Rover Imagery
        </button>
        <button
          className={`nasa-tab-btn ${activeTab === 'charts' ? 'active' : ''}`}
          onClick={() => setActiveTab('charts')}
        >
          <LineChart size={15} /> Charts & Visualization
        </button>
      </nav>

      {/* Active Module View */}
      <main>
        {activeTab === 'overview' && (
          <DataOverview 
            onNavigateTab={(tab) => setActiveTab(tab)} 
            onOpenSources={() => setIsSourcesModalOpen(true)}
            unit={unit}
            tempConvert={tempConvert}
          />
        )}

        {activeTab === 'atmosphere' && (
          <AtmosphereObservations 
            onOpenSources={() => setIsSourcesModalOpen(true)}
            unit={unit}
            tempConvert={tempConvert}
          />
        )}

        {activeTab === 'thermal' && (
          <ThermalViewer 
            onOpenSources={() => setIsSourcesModalOpen(true)}
            unit={unit}
            tempConvert={tempConvert}
          />
        )}

        {activeTab === 'geology' && (
          <GeologyMinerals 
            onOpenSources={() => setIsSourcesModalOpen(true)}
          />
        )}

        {activeTab === 'topography' && (
          <TopographyElevation 
            onOpenSources={() => setIsSourcesModalOpen(true)}
          />
        )}

        {activeTab === 'rover-imagery' && (
          <RoverImagery 
            onOpenSources={() => setIsSourcesModalOpen(true)}
          />
        )}

        {activeTab === 'charts' && (
          <DataVisualizer 
            onOpenSources={() => setIsSourcesModalOpen(true)}
            unit={unit}
            tempConvert={tempConvert}
          />
        )}
      </main>

      {/* Sources & Provenance Modal */}
      <DatasetSourcesModal 
        isOpen={isSourcesModalOpen} 
        onClose={() => setIsSourcesModalOpen(false)} 
      />
    </div>
  );
}
