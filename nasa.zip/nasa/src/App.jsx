import React, { useState } from 'react';
import { Map, Database, Shield, Rocket, Info, GitBranch, Users } from 'lucide-react';
import NasaScientificDataModule from './modules/nasa-data';

export default function App() {
  // Shared team navigation state
  // Defaulting to 'nasa-data' (Member 2's module) for testing and development
  const [activeModule, setActiveModule] = useState('nasa-data');

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', background: '#070a10', color: '#f1f5f9' }}>
      {/* Shared Project Header Navigation Bar */}
      <header style={{
        background: 'rgba(11, 15, 25, 0.95)',
        borderBottom: '1px solid rgba(224, 90, 43, 0.3)',
        padding: '0.75rem 1.5rem',
        display: 'flex',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '1rem',
        position: 'sticky',
        top: 0,
        zIndex: 50,
        backdropFilter: 'blur(10px)'
      }}>
        {/* Project Brand */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
          <div style={{
            width: '36px',
            height: '36px',
            borderRadius: '8px',
            background: 'linear-gradient(135deg, #e05a2b 0%, #7c1d02 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 0 12px rgba(224, 90, 43, 0.5)'
          }}>
            <Rocket size={20} color="#fff" />
          </div>
          <div>
            <div style={{ fontFamily: 'Orbitron, sans-serif', fontSize: '1rem', fontWeight: 700, letterSpacing: '0.06em', color: '#fff' }}>
              INTERPLANETARY SURVIVAL GUIDE
            </div>
            <div style={{ fontSize: '0.75rem', color: '#94a3b8', letterSpacing: '0.04em' }}>
              Martian Map • Integrated Three-Member Team Platform
            </div>
          </div>
        </div>

        {/* Team Module Navigation Tabs */}
        <nav style={{ display: 'flex', gap: '0.5rem', background: 'rgba(0,0,0,0.4)', padding: '4px', borderRadius: '8px', border: '1px solid rgba(255,255,255,0.08)' }}>
          {/* Member 1 Slot */}
          <button
            onClick={() => setActiveModule('martian-map')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '0.5rem 0.85rem',
              borderRadius: '6px',
              border: 'none',
              background: activeModule === 'martian-map' ? 'rgba(56, 189, 248, 0.2)' : 'transparent',
              color: activeModule === 'martian-map' ? '#38bdf8' : '#94a3b8',
              fontFamily: 'Orbitron, sans-serif',
              fontSize: '0.75rem',
              cursor: 'pointer',
              transition: 'all 0.15s ease'
            }}
          >
            <Map size={14} />
            <span>Map (Member 1)</span>
          </button>

          {/* Member 2 - OUR ASSIGNED MODULE */}
          <button
            onClick={() => setActiveModule('nasa-data')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '0.5rem 0.85rem',
              borderRadius: '6px',
              border: activeModule === 'nasa-data' ? '1px solid #e05a2b' : '1px solid transparent',
              background: activeModule === 'nasa-data' ? 'linear-gradient(135deg, rgba(224,90,43,0.3) 0%, rgba(14,20,32,0.9) 100%)' : 'transparent',
              color: activeModule === 'nasa-data' ? '#fff' : '#94a3b8',
              fontFamily: 'Orbitron, sans-serif',
              fontSize: '0.75rem',
              fontWeight: activeModule === 'nasa-data' ? 'bold' : 'normal',
              boxShadow: activeModule === 'nasa-data' ? '0 0 12px rgba(224, 90, 43, 0.35)' : 'none',
              cursor: 'pointer',
              transition: 'all 0.15s ease'
            }}
          >
            <Database size={14} color="#e05a2b" />
            <span>NASA Data (Member 2)</span>
          </button>

          {/* Member 3 Slot */}
          <button
            onClick={() => setActiveModule('survival-guide')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '0.5rem 0.85rem',
              borderRadius: '6px',
              border: 'none',
              background: activeModule === 'survival-guide' ? 'rgba(16, 185, 129, 0.2)' : 'transparent',
              color: activeModule === 'survival-guide' ? '#34d399' : '#94a3b8',
              fontFamily: 'Orbitron, sans-serif',
              fontSize: '0.75rem',
              cursor: 'pointer',
              transition: 'all 0.15s ease'
            }}
          >
            <Shield size={14} />
            <span>Survival Guide (Member 3)</span>
          </button>
        </nav>

        {/* GitHub / Team Status pill */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.72rem', color: '#64748b', fontFamily: 'monospace' }}>
          <GitBranch size={13} color="#e05a2b" />
          <span>branch: main / module-2-nasa-data</span>
        </div>
      </header>

      {/* Main Container */}
      <main style={{ flex: 1 }}>
        {/* MEMBER 1 INTEGRATION PLACEHOLDER */}
        {activeModule === 'martian-map' && (
          <div style={{ padding: '2.5rem', maxWidth: '900px', margin: '2rem auto', background: 'rgba(14, 20, 32, 0.8)', border: '1px dashed rgba(56, 189, 248, 0.4)', borderRadius: '12px', textAlign: 'center' }}>
            <div style={{ width: '48px', height: '48px', borderRadius: '50%', background: 'rgba(56, 189, 248, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem auto' }}>
              <Map size={24} color="#38bdf8" />
            </div>
            <h2 style={{ fontFamily: 'Orbitron, sans-serif', color: '#fff', fontSize: '1.25rem' }}>
              Member 1: Martian Map Integration Slot
            </h2>
            <p style={{ color: '#94a3b8', fontSize: '0.88rem', maxWidth: '600px', margin: '0.5rem auto 1.5rem auto', lineHeight: '1.5' }}>
              This tab is reserved for Member 1's interactive map, landing site GIS coordinates, and terrain rendering.
            </p>
            <div style={{ background: 'rgba(0,0,0,0.3)', padding: '1rem', borderRadius: '8px', textAlign: 'left', fontSize: '0.8rem', fontFamily: 'monospace', color: '#cbd5e1' }}>
              <div style={{ color: '#38bdf8', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                // How Member 1 can import Member 2's scientific telemetry into the map:
              </div>
              <div>import &#123; TopographyElevation, ThermalViewer, authenticNasaDatasets &#125; from './modules/nasa-data';</div>
              <div style={{ marginTop: '0.5rem', color: '#64748b' }}>// Member 1 can display MOLA elevation benchmarks directly on map pins!</div>
            </div>
          </div>
        )}

        {/* MEMBER 2: NASA SCIENTIFIC DATA INTEGRATION MODULE (OUR MODULE) */}
        {activeModule === 'nasa-data' && (
          <NasaScientificDataModule />
        )}

        {/* MEMBER 3 INTEGRATION PLACEHOLDER */}
        {activeModule === 'survival-guide' && (
          <div style={{ padding: '2.5rem', maxWidth: '900px', margin: '2rem auto', background: 'rgba(14, 20, 32, 0.8)', border: '1px dashed rgba(16, 185, 129, 0.4)', borderRadius: '12px', textAlign: 'center' }}>
            <div style={{ width: '48px', height: '48px', borderRadius: '50%', background: 'rgba(16, 185, 129, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem auto' }}>
              <Shield size={24} color="#34d399" />
            </div>
            <h2 style={{ fontFamily: 'Orbitron, sans-serif', color: '#fff', fontSize: '1.25rem' }}>
              Member 3: Interplanetary Survival Guide Integration Slot
            </h2>
            <p style={{ color: '#94a3b8', fontSize: '0.88rem', maxWidth: '600px', margin: '0.5rem auto 1.5rem auto', lineHeight: '1.5' }}>
              This tab is reserved for Member 3's life support systems, radiation shields, habitat oxygen generation, and survival protocols.
            </p>
            <div style={{ background: 'rgba(0,0,0,0.3)', padding: '1rem', borderRadius: '8px', textAlign: 'left', fontSize: '0.8rem', fontFamily: 'monospace', color: '#cbd5e1' }}>
              <div style={{ color: '#34d399', marginBottom: '0.5rem', fontWeight: 'bold' }}>
                // How Member 3 can import Member 2's environmental hazards:
              </div>
              <div>import &#123; AtmosphereObservations, GeologyMinerals &#125; from './modules/nasa-data';</div>
              <div style={{ marginTop: '0.5rem', color: '#64748b' }}>// Member 3 can consume toxic perchlorate warnings (ClO4-) and dust opacity (Tau) for emergency alerts!</div>
            </div>
          </div>
        )}
      </main>

      {/* Shared Footer */}
      <footer style={{
        background: '#04060a',
        borderTop: '1px solid rgba(255, 255, 255, 0.06)',
        padding: '1rem 1.5rem',
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: '0.5rem',
        fontSize: '0.74rem',
        color: '#64748b'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Users size={14} color="#e05a2b" />
          <span>Interplanetary Survival Guide: Martian Map — Collaborative Team Project</span>
        </div>
        <div style={{ fontFamily: 'monospace' }}>
          Member 2 Subsystem: NASA Scientific Data Integration (PDS & Open API Verified)
        </div>
      </footer>
    </div>
  );
}
