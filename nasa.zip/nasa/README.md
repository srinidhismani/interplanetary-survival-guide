# Interplanetary Survival Guide: Martian Map

A collaborative, three-member integrated web application engineered for human survival, spatial navigation, and scientific exploration on the surface of Mars.

---

## Team Subsystem Architecture

This project is partitioned into three specialized modules designed to integrate into a unified React platform:

| Member | Subsystem | Responsibility | Directory |
|---|---|---|---|
| **Member 1** | **Martian Map** | Interactive surface GIS, coordinates, landing sites & terrain mapping | `src/modules/martian-map/` |
| **Member 2** | **NASA Scientific Data Integration** | Authentic NASA environmental telemetry, thermal regimes, geology, topography, rover observations & charts | `src/modules/nasa-data/` |
| **Member 3** | **Survival Guide** | Life support logistics, habitat pressurization, radiation shielding & survival protocols | `src/modules/survival-guide/` |

---

## Member 2 Subsystem: NASA Scientific Data Integration

### Assigned Features (Fully Implemented)
1. **NASA Scientific Data Display**: High-level planetary constants (GSFC) and active fleet telemetry (Perseverance, Curiosity, InSight, MRO, Odyssey, MAVEN).
2. **Mars Thermal Information**: 2001 Mars Odyssey THEMIS global thermal inertia datasets, diurnal surface vs subsurface (-10cm) damping curves, and frost condensation line risks.
3. **Geological & Mineral Information**: Regolith oxide abundance (SiO2, FeO, MgO, Al2O3, SO3) with critical alerts for toxic **Perchlorates (ClO4-)**, plus CRISM hyperspectral mineral identification (clays, hydrated sulfates, olivine, hematite, carbonates).
4. **Topographic & Elevation Information**: MGS MOLA 0m datum (610.5 Pa water triple point reference), Olympus Mons (+21.2 km) to Hellas Planitia (-7.1 km) benchmarks, and 250 km cross-sectional elevation transect of Valles Marineris.
5. **Atmospheric Observations**: Mars 2020 Perseverance MEDA 7-Sol calibrated weather records (Sol 915-921) at Jezero Crater, atmospheric gas breakdown (95.3% CO2, MOXIE O2 extraction), dust optical depth (Tau), and 25-30% annual polar CO2 pressure cycles.
6. **Mars Rover Imagery & In-Situ Observations**: Live NASA Mars Rover Photos API query engine + curated NASA/JPL-Caltech high-res image gallery, instrument filtering, and full metadata lightbox.
7. **Charts & Data Visualization**: Interactive SVG analytical visualizations (diurnal temperature swings, annual pressure cycles, elevation profiles, regolith assays).
8. **Provenance & Dataset Provenance Display**: Comprehensive attribution displaying exact NASA missions, instruments, observation Sols/dates, and clear labeling between verified NASA PDS ground truth archives and sample data.

---

## Quickstart & Local Execution

### Prerequisites
- Node.js (v18+)
- npm (v9+)

### Installation
```bash
# Clone the repository
git clone <repository-url>
cd nasa

# Install dependencies
npm install

# Start Vite development server
npm run dev
```

### Production Build
```bash
npm run build
npm run preview
```

---

## Member 2 Module Integration Guide

Member 1 and Member 3 can easily integrate Member 2's components into their respective views or shared navigation:

### 1. Full Module Import
```jsx
import NasaScientificDataModule from './modules/nasa-data';

// Inside your component or router:
<NasaScientificDataModule initialTab="overview" defaultUnit="C" />
```

### 2. Individual Component Imports
```jsx
// Topography benchmarks for Member 1's Map:
import { TopographyElevation } from './modules/nasa-data';

// Atmospheric and Toxic Perchlorate alerts for Member 3's Survival Guide:
import { AtmosphereObservations, GeologyMinerals } from './modules/nasa-data';
```
